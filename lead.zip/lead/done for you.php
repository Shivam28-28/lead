<?php include 'header.php'; ?>

<style>
    .main-header {
    /* add your styles for the main header here */
    background-color: #f0f0f0; /* example style */
    padding: 40px; /* example style */
}

.combined-section {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-top: 20px;
}

.combined-section .container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.combined-section .row {
  display: flex;
  flex-wrap: wrap;
}

.combined-section .col-md-6 {
  flex-basis: 50%;
  max-width: 50%;
}

.new-section {
  background-color: #fff; /* white background */
  padding: 40px 0;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.row {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
}

.col-md-05 {
  flex-basis: 40%;
  margin: 20px;
}

.col-md-07 {
  flex-basis: 60%;
  margin: 20px;
}

.image {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 10px;
}

.heading {
  font-size: 24px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}

.description {
  font-size: 18px;
  color: #666;
  line-height: 1.5;
  margin-bottom: 20px;
}

.btn {
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.btn:hover {
  background-color: #3e8e41;
}

/* Responsive design */
@media (max-width: 768px) {
  .col-md-05 {
    flex-basis: 100%;
    margin: 10px;
  }
  .image {
    height: 150px;
  }
}
.logo {
  text-align: center;
}

.logo-image {
  width: 100%;
  height: auto;
  max-width: 300px;
  margin: 20px auto;
}

.dropdown {
    /* add your styles for the dropdown menu here */
    position: relative; /* example style */
    display: inline-block; /* example style */
}

.dropbtn {
    /* add your styles for the dropdown button here */
    background-color: ;/* example style */
    color: #333333; /* example style */
    padding: 10px; /* example style */
    border: none; /* example style */
    cursor: pointer; /* example style */
}


nav ul {
    /* add your styles for the navigation menu here */
    list-style: none; /* example style */
    margin: 0; /* example style */
    padding: 0; /* example style */
    display: flex; /* example style */
    justify-content: space-between; /* example style */
}

nav li {
    /* add your styles for the navigation menu items here */
    margin-right: 20px; /* example style */
}

nav a {
    /* add your styles for the navigation menu links here */
    color: #333; /* example style */
    text-decoration: none; /* example style */
}

nav a:hover {
    /* add your styles for the navigation menu links on hover here */
    color: #666; /* example style */
}
.in{
    text-transform: capitalize; /* converts the text to lowercase */
  font-size: 24px; /* sets the font size to 36 pixels */
  font-weight: bold; /* sets the font weight to bold */
  color: #333; /* sets the text color to a dark gray */
  margin-bottom: 50px; /* adds a margin of 10 pixels to the bottom */
  text-align: center;
  padding-top: 90px;
}
.to
{
    text-transform: capitalize; /* converts the text to lowercase */
  font-size: 20px; /* sets the font size to 36 pixels */
  font-weight: bold; /* sets the font weight to bold */
  color: #333; /* sets the text color to a dark gray */
  margin-bottom: 50px; /* adds a margin of 10 pixels to the bottom */
  text-align: center;
  padding-top: 0px;
}
.you
{
    text-transform: capitalize; /* converts the text to lowercase */
  font-size: 20px; /* sets the font size to 36 pixels */
  font-weight: normal; /* sets the font weight to bold */
  color: #333; /* sets the text color to a dark gray */
  margin-bottom: 50px; /* adds a margin of 10 pixels to the bottom */
  text-align: center;
  padding-top: 0px;
}
.animated-button {
        background-color: #1085afe3; /* green background */
        color: #fff; /* white text */
        border: none; /* no border */
        padding: 10px 20px; /* padding */
        font-size: 30px; /* font size */
        cursor: pointer; /* pointer cursor */
        border-radius: 5px; /* rounded corners */
        transition: background-color 0.3s; /* transition effect */
       
    }

    .animated-button:hover {
        background-color: #87CEFA; /* darker green on hover */
    }

    .animated-button:active {
        background-color: #2e6c31; /* even darker green on active */
        transform: translateY(2px); /* slight movement on active */
    }
    .button-container {
    display: flex;
    justify-content: center;
    margin-top: 20px; /* adjust as needed */
}
.is{
    text-transform: capitalize; /* converts the text to lowercase */
  font-size: 30px; /* sets the font size to 36 pixels */
  font-weight: bold; /* sets the font weight to bold */
  color: #333; /* sets the text color to a dark gray */
  
  padding-left: 30px;
  text-decoration: underline;
}
.get{
  text-transform: normal; /* converts the text to lowercase */
  font-size: 20px; /* sets the font size to 36 pixels */
  color: #333; /* sets the text color to a dark gray */
  padding-left: 0;  
}
.new-section.alternative {
   /* light gray background */
  padding: 40px; /* add some padding to the section */
}

.alternative .image {
  border-radius: 10px; /* add a rounded corner to the image */
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* add a subtle shadow to the image */
  padding-right: 20px; /* add 20px of right padding to the image */
}

.alternative .heading {
  color: #333; /* darker text color */
  font-weight: bold; /* make the heading bold */
}

.alternative .description {
  font-size: 18px; /* slightly larger font size */
  line-height: 1.5; /* add some line spacing for better readability */
}

.alternative .btn {
  background-color: #4caf50; /* blue button color */
  color: #fff; /* white text color */
  padding: 10px 20px; /* add some padding to the button */
  border-radius: 5px; /* add a rounded corner to the button */
}


</style>

<header class="main-header">
    <nav>
        <ul>
        <li class="dropdown">
  <a href="done for you.php" class="dropbtn">Done for you <i class="fa fa-caret-down"></i></a>
  
</li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>  

</header>  

<div class="in">
<h1>Digital Marketing Services</h1>
</div>

<div class="to">
    <h2>
    DONE FOR YOU
    </h2>
</div>

<p class="You">
Still Don't Know What You Need? We're Happy to Help You Decide. <br>
Fill Out the Form Below to Get Started.
</p>

<div class="button-container">
    <a href="contact.php" class="animated-button">Inquiry</a>
</div>

<section class="new-section">
  <div class="container">
    <div class="row">
      <div class="col-md-05">
        <img class="image" src="img/istockphoto-1125819931-612x612.jpg" alt="Image">
      </div>
      <div class="col-md-07">
        <h2 class="heading">Unlock the Power of Your Wallet</h2>
        <p class="description">
          Take your spending to the next level with our credit card. Earn rewards, cashback, and enjoy special offers. Learn more about our credit card offers and start maximizing your spending today.
        </p>
        <a href="credit.php" class="btn">Credit card</a>
      </div>
    </div>
  </div>
</section>


<section class="combined-section">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h2 class="is">Real State</h2>
        <p class="Get">
        A real estate lead generator should focus on attracting potential buyers, sellers, and investors by providing valuable information and a clear call-to-action. Below is a sample structure you can use for your real estate lead generation landing page:
        </p>
        <a href="real.php" class="btn">Real</a>
      </div>
      <div class="col-md-6">
        <div class="logo">
          <img class="logo-image" src="img/istockphoto-1125819931-612x612.jpg" alt="Logo">
        </div>
      </div>
    </div>
  </div>
</section>


<section class="new-section alternative">
  <div class="container">
    <div class="row">
      <div class="col-md-05">
        <img class="image alternative" src="img/download.jfif" alt="Alternative Image">
      </div>
      <div class="col-md-07">
        <h2 class="heading alternative">Comprehensive Insurance Solutions</h2>
        <p class="description alternative">
          Explore the world of possibilities with our innovative solutions. Learn more about our latest offerings and start achieving your goals today.
        </p>
        <a href="insurance.php" class="btn alternative">Insurance </a>
      </div>
    </div>
  </div>
</section>