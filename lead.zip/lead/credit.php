<style>

.credit-card-section {
  background-color: #f7f7f7; /* light gray background */
  padding: 40px 0;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.row {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
}

.col-md-06 {
  flex-basis: 50%;
  margin: 20px;
  font-size: 25px;
}

.heading {
  font-size: 35px;
  font-weight: bold;
  color: #333;
  /* margin-bottom: 10px; */
}

.description {
  font-size: 28px;
  color: #666;
  line-height: 1.5;
  margin-bottom: 30px;
}

.btn {
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.btn:hover {
  /* background-color: #3e8e41; */
}

.why-choose-us {
  margin-bottom: 20px;
}

.why-choose-us ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.why-choose-us li {
  margin-bottom: 10px;
}

.why-choose-us i {
  color: #4CAF50;
  margin-right: 10px;
}

.how-it-works {
  margin-bottom: 20px;
}

.how-it-works ol {
  list-style: decimal;
  padding: 0;
  margin: 0;
}

.how-it-works li {
  margin-bottom: 10px;
}

/* Responsive design */
@media (max-width: 768px) {
  .col-md-06 {
    flex-basis: 100%;
    margin: 10px;
  }
}

</style>

<section class="credit-card-section">
  <div class="container">
    <div class="row">
      <div class="col-md-06">
        <h2 class="heading">Find the Perfect Credit Card for Your Needs!</h2>
        <p class="description">
          Looking for a credit card that fits your lifestyle? Whether you're looking for cashback, travel rewards, or low interest rates, we’ve got the perfect card for you. Apply today and start enjoying exclusive benefits.
        </p>
        <a href="contact.php" class="btn">Apply Now</a>
      </div>
      <div class="col-md-06">
        <div class="why-choose-us">
          <h3>Why Choose Us?</h3>
          <ul>
            <li><i class="fas fa-check"></i> Instant Approval: Get approved within minutes!</li>
            <li><i class="fas fa-check"></i> No Annual Fees: Enjoy a hassle-free credit card with zero fees.</li>
            <li><i class="fas fa-check"></i> Low-Interest Rates: Save more with our competitive rates.</li>
            <li><i class="fas fa-check"></i> Rewards & Cashback: Earn points and cashback on every purchase.</li>
            <li><i class="fas fa-check"></i> Exclusive Offers: Unlock special deals on dining, travel, and more.</li>
          </ul>
        </div>
        <div class="how-it-works">
          <h3>How It Works:</h3>
          <ol>
            <li>Fill Out Your Details: Complete the quick form with your information.</li>
            <li>Get Matched: We’ll find the best credit card offers tailored just for you.</li>
            <li>Apply Online: Apply directly online and get approved in minutes!</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>