<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle form submission here
    // You can store the form data in a database or send it to an email address
    // For this example, we'll just display a thank you message
    $thankYouMessage = "Thank you for submitting the form!";
} else {
    $thankYouMessage = "";
}
?>

<?php include 'header.php'; ?>

<style>

body {
    background-color: #f8e6e6;
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: left; /* Add this to center the content horizontally */
}

h1 {
    text-align: center;
    color: #444;
    font-family: 'Cursive', sans-serif;
}

form {
    display: flex;
    flex-direction: column;
}

.input-group {
    display: flex;
    flex-direction: column;
    margin-bottom: 15px;
}

.input-group label {
    font-size: 14px;
    color: #555;
    margin-bottom: 5px;
}

.input-group small {
    font-size: 12px;
    color: #777;
}

.input-group input, .input-group select {
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    outline: none;
    transition: border-color 0.3s;
}

.input-group input:focus, .input-group select:focus {
    border-color: #ff6b6b;
}

.input-group input[type="text"],
.input-group input[type="tel"],
.input-group input[type="email"],
.input-group input[type="date"] {
    width: 100%;
    margin-bottom: 10px;
}

.input-group select {
    width: 100%;
}

input::placeholder {
    color: #aaa;
}

span {
    color: red;
    font-size: 16px;
}

   
    .main-header {
    /* add your styles for the main header here */
    background-color: #f0f0f0; /* example style */
    padding: 40px; /* example style */
}

.logo {
    /* add your styles for the logo here */
    width: 40px; /* example style */
    height: 40px; /* example style */
}

.dropdown {
    /* add your styles for the dropdown menu here */
    position: relative; /* example style */
    display: inline-block; /* example style */
}

.dropbtn {
    /* add your styles for the dropdown button here */
    background-color: ;/* example style */
    color: #333333; /* example style */
    padding: 10px; /* example style */
    border: none; /* example style */
    cursor: pointer; /* example style */
}


nav ul {
    /* add your styles for the navigation menu here */
    list-style: none; /* example style */
    margin: 0; /* example style */
    padding: 0; /* example style */
    display: flex; /* example style */
    justify-content: space-between; /* example style */
}

nav li {
    /* add your styles for the navigation menu items here */
    margin-right: 20px; /* example style */
}

nav a {
    /* add your styles for the navigation menu links here */
    color: #333; /* example style */
    text-decoration: none; /* example style */
}

nav a:hover {
    /* add your styles for the navigation menu links on hover here */
    color: #666; /* example style */
}
.main-footer {
    background-color: #f0f0f0; /* example style */
    padding: 20px; /* example style */
    text-align: center; /* example style */
}

.main-footer ul {
    list-style: none; /* example style */
    margin: 0; /* example style */
    padding: 0; /* example style */
    display: flex; /* example style */
    justify-content: space-between; /* example style */
}

.main-footer li {
    margin-right: 20px; /* example style */
}

.main-footer a {
    color: #333; /* example style */
    text-decoration: none; /* example style */
}

.main-footer a:hover {
    color: #666; /* example style */
}
footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: #fff;
}

</style>

<script>
        function showThankYouMessage(message) {
            if (message) {
                alert(message);
            }
        }
    </script>

<header class="main-header">
    <div class="logo">
        <!-- <img src="img/8b0bcb2bbe745265d0cf8864a187ab1c.jpg" alt="Logo"> -->
    </div>
    <nav>
        <ul>
        <li class="dropdown">
  <a href="done for you.php" class="dropbtn">Done for you <i class="fa fa-caret-down"></i></a>
  
</li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>  
</header>

<body onload="showThankYouMessage('<?php echo $thankYouMessage; ?>')">
    <div class="container">
        <h1>Sweets Inquiry Form</h1>
        <form method="post">
        <form>
            <div class="input-group">
                <label for="first-name">Name:</label>
                <input type="text" id="first-name" placeholder="First">
                <input type="text" id="last-name" placeholder="Last">
            </div>

            <div class="input-group">
                <label for="contact">Contact number: <span>*</span></label>
                <input type="tel" id="contact" placeholder="### ### ####" required>
            </div>

            <div class="input-group">
                <label for="email">Email address: <span>*</span></label>
                <input type="email" id="email" placeholder="Email" required>
            </div>

            <div class="input-group">
                <label for="event-date">Event date: <span>*</span></label>
                <input type="date" id="event-date" required>
            </div>

            <div class="input-group">
                <label for="address1">Delivery Address: <small>(If Applicable)</small></label>
                <input type="text" id="address1" placeholder="Street Address">
                <input type="text" id="address2" placeholder="Street Address Line 2">
                <input type="text" id="city" placeholder="City">
                <input type="text" id="region" placeholder="Region">
                <input type="text" id="postal" placeholder="Postal / Zip Code">
                <select id="country" name="country">
                <option value="" disabled selected>Select your country</option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="Bulgeria">Bulgeria</option>
                <option value="India">India</option>
                <option value="America">America</option>
                <option value="China">China</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Japan">Japan</option>
                </select>
            </div>
            <div>
    <input type="checkbox" id="terms" name="terms" required>
    <label for="terms">
        I agree to the <a href="Terms & Conditions.php">Terms & Conditions</a>
    </label>
</div>
<br>
<div style="display: flex; align-items: center;">
    <input type="checkbox" id="RCS" name="RCS" required>
    <label for="RCS" style="margin-left: 8px;">
        I agree to receive communication about newsletters, promotional content, offers, and events through SMS, RCS, and WhatsApp.
    </label>
</div>
<br>
            <div class="input-group">
                <input type="submit" value="Submit">
            </div>
        </form>
      

        <!-- <?php echo $thankYouMessage; ?> -->
    </div>

    <footer>
        <p>&copy; 2024 Real Estate Services. All rights reserved.</p>
    </footer>
</body>