<!DOCTYPE html>
<html lang="en">

<head>
  <title>Terms & Conditions</title>
</head>

<body>

  <!-- ======= Terms & Conditions ======= -->
  <section id="terms" class="terms-section">

    <div class="container">
      <div class="row">

        <div class="col-lg-12 col-md-12">
          <h3>Terms & Conditions</h3>
          <p>
            Welcome to Infinity Solution. By accessing or using our services, you agree to comply with and be bound by the following terms and conditions. Please read them carefully.
          </p>

          <h4>1. Acceptance of Terms</h4>
          <p>
            By accessing this website, you agree to be bound by these Terms and Conditions of use, all applicable laws, and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>

          <h4>2. Services Provided</h4>
          <p>
            Infinity Solution offers a range of digital marketing and communication services. All services provided are subject to the terms and conditions set forth in this agreement.
          </p>

          <h4>3. User Obligations</h4>
          <p>
            You agree to use our services only for lawful purposes. You agree not to take any action that may compromise the security of our website or render the website inaccessible to others.
          </p>

          <h4>4. Limitation of Liability</h4>
          <p>
            Infinity Solution will not be liable for any damages arising from the use or inability to use the materials on this website, even if Infinity Solution or an authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>

          <h4>5. Governing Law</h4>
          <p>
            Any claim relating to Infinity Solution's website shall be governed by the laws of the State of Gujarat without regard to its conflict of law provisions.
          </p>

          <h4>6. Changes to Terms</h4>
          <p>
            Infinity Solution reserves the right to revise these terms of service at any time without notice. By using this website, you are agreeing to be bound by the then-current version of these Terms and Conditions.
          </p>

          <p>
            If you have any questions or concerns about these terms, please contact us at: <br>
            <strong>Email:</strong> mitul@infisms.com<br>
            <strong>Phone:</strong> +91 98984 39675<br>
          </p>
        </div>

      </div>
    </div>

  </section><!-- End Terms & Conditions -->

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>