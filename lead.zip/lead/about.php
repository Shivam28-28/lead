


<?php include 'header.php'; ?>

<style>
    .main-header {
    /* add your styles for the main header here */
    background-color: #f0f0f0; /* example style */
    padding: 40px; /* example style */
}

.logo {
    /* add your styles for the logo here */
    width: 40px; /* example style */
    height: 40px; /* example style */
}

.dropdown {
    /* add your styles for the dropdown menu here */
    position: relative; /* example style */
    display: inline-block; /* example style */
}

.dropbtn {
    /* add your styles for the dropdown button here */
    background-color: ;/* example style */
    color: #333333; /* example style */
    padding: 10px; /* example style */
    border: none; /* example style */
    cursor: pointer; /* example style */
}


nav ul {
    /* add your styles for the navigation menu here */
    list-style: none; /* example style */
    margin: 0; /* example style */
    padding: 0; /* example style */
    display: flex; /* example style */
    justify-content: space-between; /* example style */
}

nav li {
    /* add your styles for the navigation menu items here */
    margin-right: 20px; /* example style */
}

nav a {
    /* add your styles for the navigation menu links here */
    color: #333; /* example style */
    text-decoration: none; /* example style */
}

nav a:hover {
    /* add your styles for the navigation menu links on hover here */
    color: #666; /* example style */
}
.about-us {
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
  background-color: #f9f9f9;
  border: 1px solid #ddd;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.about-us h1 {
  font-size: 24px;
  margin-top: 0;
}

.what-we-do, .our-approach, .why-choose-us {
  margin-bottom: 20px;
}

.what-we-do h2, .our-approach h2, .why-choose-us h2 {
  font-size: 18px;
  margin-top: 0;
}

.our-approach ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.our-approach li {
  margin-bottom: 10px;
}

.our-approach h3 {
  font-size: 16px;
  margin-top: 0;
}

.why-choose-us ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.why-choose-us li {
  margin-bottom: 10px;
}

.why-choose-us h3 {
  font-size: 16px;
  margin-top: 0;
}
footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: #fff;
}
</style>

<header class="main-header">
    <div class="logo">
        <!-- <img src="img/8b0bcb2bbe745265d0cf8864a187ab1c.jpg" alt="Logo"> -->
    </div>
    <nav>
        <ul>
        <li class="dropdown">
  <a href="done for you.php" class="dropbtn">Done for you <i class="fa fa-caret-down"></i></a>
  
</li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>  
</header>

<section class="about-us">
  <h1>About Us</h1>
  <p>At [Your Company Name], we specialize in helping businesses grow through smart and efficient lead generation strategies. Our goal is to connect you with potential customers who are genuinely interested in your products or services.</p>
  <section class="what-we-do">
    <h2>What We Do</h2>
    <p>We combine data-driven insights, innovative technology, and personalized marketing techniques to attract high-quality leads. From capturing interest through targeted campaigns to nurturing relationships, we streamline the entire process to boost your sales pipeline.</p>
  </section>
  <section class="our-approach">
    <h2>Our Approach</h2>
    <ul>
      <li>
        <h3>Tailored Solutions</h3>
        <p>We understand that every business is unique. That’s why we customize our lead generation strategies to meet your specific goals and industry needs.</p>
      </li>
      <li>
        <h3>Cutting-Edge Technology</h3>
        <p>Using advanced tools and platforms, we ensure the leads you get are not only relevant but also ready to convert.</p>
      </li>
      <li>
        <h3>Proven Expertise</h3>
        <p>With a team of skilled professionals, we bring years of experience in digital marketing and customer acquisition.</p>
      </li>
    </ul>
  </section>
  <section class="why-choose-us">
    <h2>Why Choose Us?</h2>
    <ul>
      <li>
        <h3>Results-Driven</h3>
        <p>We focus on delivering leads that turn into real business opportunities.</p>
      </li>
      <li>
        <h3>Transparency</h3>
        <p>We keep you informed every step of the way, providing detailed reports and insights.</p>
      </li>
      <li>
        <h3>Supportive Team</h3>
        <p>Our dedicated team is here to support you throughout the lead generation journey, offering continuous optimization and guidance.</p>
      </li>
    </ul>
    <p>Let us help you unlock the potential of your business by delivering the leads that matter!</p>
  </section>
</section>

<footer>
        <p>&copy; 2024 Shivam. All rights reserved.</p>
    </footer>