<style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #3b5998;
    color: #fff;
    padding: 30px;
    text-align: center;
}

h1 {
    margin: 0;
}

.cta-btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #f39c12;
    color: #fff;
    text-decoration: none;
    margin-top: 20px;
    border-radius: 5px;
}

section {
    padding: 40px 20px;
    background-color: #fff;
    margin: 20px 0;
}

h2 {
    color: #333;
}

ul, ol {
    padding-left: 20px;
}

footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: #fff;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-bottom: 5px;
}

input, textarea {
    margin-bottom: 15px;
    padding: 10px;
    width: 100%;
    max-width: 500px;
}

button {
    padding: 10px;
    background-color: #3b5998;
    color: #fff;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #2c3e50;
}

.listing {
    border: 1px solid #ccc;
    padding: 20px;
    margin-bottom: 20px;
}

</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Find Your Dream Home | Real Estate Services</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to CSS file -->
</head>
<body>
    <header>
        <h1>Find Your Dream Home or Sell Faster – Get Expert Help Now!</h1>
        <p>Whether you're buying or selling, we're here to help you every step of the way. Get a Free Consultation or Property Evaluation!</p>
        <a href="contact.php" class="cta-btn">Get Free Consultation</a>
    </header>

    <section id="why-choose-us">
        <h2>Why Choose Us?</h2>
        <ul>
            <li><strong>Experienced Agents:</strong> Our team has over X years of experience in the local market.</li>
            <li><strong>Fast Results:</strong> Get offers in as little as 30 days or less for your property.</li>
            <li><strong>Wide Range of Listings:</strong> From luxurious homes to budget-friendly options, we have something for everyone.</li>
            <li><strong>Personalized Service:</strong> We understand your needs and provide tailored advice for buyers and sellers alike.</li>
        </ul>
    </section>

    <section id="how-it-works">
        <h2>How It Works</h2>
        <ol>
            <li><strong>Tell Us What You Need:</strong> Fill out our quick form and we’ll match you with the right agent.</li>
            <li><strong>Get a Free Evaluation:</strong> Our experts will give you a no-obligation consultation or property value estimate.</li>
            <li><strong>Start the Journey:</strong> We’ll guide you through buying or selling your home step by step.</li>
        </ol>
    </section>

    <section id="expertise">
        <h2>Our Expertise Covers</h2>
        <ul>
            <li><strong>Home Buyers:</strong> New buyers, experienced buyers, and those relocating.</li>
            <li><strong>Home Sellers:</strong> Property valuation, staging, and marketing strategies to sell faster.</li>
            <li><strong>Investors:</strong> Guidance on market trends and investment opportunities in real estate.</li>
        </ul>
    </section>

    <section id="featured-listings">
        <h2>Featured Listings</h2>
        <div class="listing">
            <img src="images/property1.jpg" alt="Property 1">
            <p><strong>Price:</strong> $500,000</p>
            <p><strong>Location:</strong> New York, NY</p>
            <p><strong>Key Features:</strong> 3 Bed, 2 Bath, Modern Design, Near Park</p>
        </div>
        <!-- Add more property listings here -->
    </section>

    <!-- <section id="consultation-form">
        <h2>Get a Free Consultation</h2>
        <form action="submit_form.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="message">What Are You Looking For?</label>
            <textarea id="message" name="message" rows="5" required></textarea>

            <button type="submit">Submit</button>
        </form>
    </section> -->

    <footer>
        <p>&copy; 2024 Real Estate Services. All rights reserved.</p>
    </footer>
</body>
</html>
